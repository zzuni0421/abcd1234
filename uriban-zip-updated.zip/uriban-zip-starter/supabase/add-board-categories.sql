-- 우리반.zip 게시판 3종 추가 마이그레이션
-- 기존 게시글 데이터는 삭제하지 않습니다.

DO $$
DECLARE
  constraint_name text;
BEGIN
  FOR constraint_name IN
    SELECT con.conname
    FROM pg_constraint con
    JOIN pg_class tbl ON tbl.oid = con.conrelid
    JOIN pg_namespace ns ON ns.oid = tbl.relnamespace
    WHERE ns.nspname = 'public'
      AND tbl.relname = 'posts'
      AND con.contype = 'c'
      AND pg_get_constraintdef(con.oid) ILIKE '%category%'
  LOOP
    EXECUTE format('ALTER TABLE public.posts DROP CONSTRAINT %I', constraint_name);
  END LOOP;
END $$;

ALTER TABLE public.posts
  ADD CONSTRAINT posts_category_check
  CHECK (category IN ('free', 'study', 'qna', 'homework', 'album', 'notice'));

-- 변경 결과 확인
SELECT category, count(*) AS post_count
FROM public.posts
GROUP BY category
ORDER BY category;
