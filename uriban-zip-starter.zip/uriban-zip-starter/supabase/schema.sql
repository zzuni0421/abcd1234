-- 우리반.zip schema. Supabase SQL Editor에서 실행하세요.
-- 이 파일을 기존 DB에 적용하기 전에는 반드시 백업/테스트 프로젝트를 권장합니다.

create extension if not exists pgcrypto;

create table if not exists public.classrooms (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 80),
  join_code text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null check (char_length(nickname) between 2 and 20),
  role text not null default 'student' check (role in ('student','admin')),
  classroom_id uuid references public.classrooms(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  classroom_id uuid not null references public.classrooms(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  category text not null default 'free' check (category in ('free','study','notice')),
  title text not null check (char_length(title) between 1 and 120),
  body text not null check (char_length(body) between 1 and 10000),
  is_notice boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  parent_id uuid references public.comments(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

create index if not exists posts_classroom_created_idx on public.posts(classroom_id, created_at desc);
create index if not exists comments_post_created_idx on public.comments(post_id, created_at);
create index if not exists profiles_classroom_idx on public.profiles(classroom_id);

-- Signup metadata에서 닉네임을 가져와 프로필을 만듭니다.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, nickname)
  values (
    new.id,
    coalesce(
      nullif(trim(new.raw_user_meta_data ->> 'nickname'), ''),
      '새 친구'
    )
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- 클라이언트가 초대 코드를 직접 읽지 않고, 이 RPC로만 가입합니다.
create or replace function public.join_class_with_code(p_invite_code text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
  v_classroom_id uuid;
begin
  if v_user_id is null then
    raise exception 'Authentication required';
  end if;

  if p_invite_code is null or length(trim(p_invite_code)) < 6 then
    raise exception 'Invalid invite code';
  end if;

  select c.id into v_classroom_id
  from public.classrooms c
  where c.join_code = trim(p_invite_code)
  limit 1;

  if v_classroom_id is null then
    raise exception 'Invalid invite code';
  end if;

  insert into public.profiles (id, nickname, classroom_id)
  values (v_user_id, '새 친구', v_classroom_id)
  on conflict (id) do update
    set classroom_id = excluded.classroom_id
    where public.profiles.classroom_id is null;

  if not exists (
    select 1 from public.profiles p
    where p.id = v_user_id and p.classroom_id = v_classroom_id
  ) then
    raise exception 'Account already belongs to a classroom';
  end if;

  return v_classroom_id;
end;
$$;

revoke all on function public.join_class_with_code(text) from public, anon;
grant execute on function public.join_class_with_code(text) to authenticated;

-- RLS: 브라우저 클라이언트가 접근하는 모든 public 테이블에 적용합니다.
alter table public.classrooms enable row level security;
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;

revoke all on public.classrooms from anon, authenticated;
revoke all on public.profiles from anon, authenticated;
revoke all on public.posts from anon, authenticated;
revoke all on public.comments from anon, authenticated;

grant select on public.classrooms to authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.posts to authenticated;
grant select, insert, delete on public.comments to authenticated;

-- Membership helper. Security definer avoids recursive RLS evaluation.
create or replace function public.current_classroom_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select p.classroom_id from public.profiles p where p.id = auth.uid()
$$;
revoke all on function public.current_classroom_id() from public, anon;
grant execute on function public.current_classroom_id() to authenticated;

create or replace function public.current_user_is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((select p.role = 'admin' from public.profiles p where p.id = auth.uid()), false)
$$;
revoke all on function public.current_user_is_admin() from public, anon;
grant execute on function public.current_user_is_admin() to authenticated;

-- Classroom metadata is visible only to its members.
drop policy if exists "members read their classroom" on public.classrooms;
create policy "members read their classroom"
on public.classrooms for select to authenticated
using (id = (select public.current_classroom_id()));

-- Profiles are visible within the same classroom. Users may edit only their nickname.
drop policy if exists "members read profiles in class" on public.profiles;
create policy "members read profiles in class"
on public.profiles for select to authenticated
using (classroom_id is not null and classroom_id = (select public.current_classroom_id()));

drop policy if exists "users update own nickname only" on public.profiles;
create policy "users update own nickname only"
on public.profiles for update to authenticated
using (id = auth.uid() and classroom_id = (select public.current_classroom_id()))
with check (
  id = auth.uid()
  and classroom_id = (select public.current_classroom_id())
  and role = (select p.role from public.profiles p where p.id = auth.uid())
);

-- No client-side profile inserts: profile creation is trigger/RPC only.
-- Column-level grants prevent role/classroom changes via direct updates.
revoke update on public.profiles from authenticated;
grant update (nickname) on public.profiles to authenticated;

-- Posts are readable only within the user's class.
drop policy if exists "members read class posts" on public.posts;
create policy "members read class posts"
on public.posts for select to authenticated
using (classroom_id = (select public.current_classroom_id()));

drop policy if exists "members create own class posts" on public.posts;
create policy "members create own class posts"
on public.posts for insert to authenticated
with check (
  author_id = auth.uid()
  and classroom_id = (select public.current_classroom_id())
  and (is_notice = false or ((select public.current_user_is_admin()) and category = 'notice'))
);

drop policy if exists "authors or admins update posts" on public.posts;
create policy "authors or admins update posts"
on public.posts for update to authenticated
using (
  classroom_id = (select public.current_classroom_id())
  and (author_id = auth.uid() or (select public.current_user_is_admin()))
)
with check (
  classroom_id = (select public.current_classroom_id())
  and (author_id = auth.uid() or (select public.current_user_is_admin()))
  and (is_notice = false or (select public.current_user_is_admin()))
);

drop policy if exists "authors or admins delete posts" on public.posts;
create policy "authors or admins delete posts"
on public.posts for delete to authenticated
using (
  classroom_id = (select public.current_classroom_id())
  and (author_id = auth.uid() or (select public.current_user_is_admin()))
);

-- Comments inherit classroom access through the parent post.
drop policy if exists "members read comments in class" on public.comments;
create policy "members read comments in class"
on public.comments for select to authenticated
using (
  exists (
    select 1 from public.posts p
    where p.id = post_id and p.classroom_id = (select public.current_classroom_id())
  )
);

drop policy if exists "members add comments to class posts" on public.comments;
create policy "members add comments to class posts"
on public.comments for insert to authenticated
with check (
  author_id = auth.uid()
  and exists (
    select 1 from public.posts p
    where p.id = post_id and p.classroom_id = (select public.current_classroom_id())
  )
  and (
    parent_id is null
    or exists (
      select 1 from public.comments parent
      where parent.id = parent_id and parent.post_id = comments.post_id
    )
  )
);

drop policy if exists "authors or admins delete comments" on public.comments;
create policy "authors or admins delete comments"
on public.comments for delete to authenticated
using (
  author_id = auth.uid()
  or (select public.current_user_is_admin())
);

-- Important: do not grant anon access. service_role remains backend-only.
